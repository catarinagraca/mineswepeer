export default function Footer() {
  return (
    <footer>
      <p>© D E I S @ I S EC</p>
    </footer>
  );
}
